package com.example.jagjot.androidriderapp.Remote;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


//this class contains fcmclient i.e firebase cloud messaging client which using the retrofit to convert the baseurl content with GsonConverterFactory

public class FCMClient {

    private static Retrofit retrofit = null;
    public static Retrofit getClient(String baseURL)
    {
        if(retrofit == null)
        {
            retrofit = new Retrofit.Builder()
                    .baseUrl(baseURL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

}

package com.example.jagjot.androidriderapp.Common;

import com.example.jagjot.androidriderapp.Remote.FCMClient;
import com.example.jagjot.androidriderapp.Remote.GoogleMapAPI;
import com.example.jagjot.androidriderapp.Remote.IFCMService;
import com.example.jagjot.androidriderapp.Remote.IGoogleAPI;

/**
 * Created by JAGJOT on 2/28/2018.
 */
// this java file contains all the table

public class Common {

    public static boolean isDriverFound = false;
    public static String driverId="";
    public static final String driver_tbl = "Drivers";
    public static final String user_driver_tbl = "DriversInformation";
    public static final String user_rider_tbl = "RidersInformation";
    public static final String pickup_request_tbl = "PickupRequest";
    public static final String token_tbl = "Tokens";
    public static final String rate_detail_tbl = "RateDetails";

    public static final String fcmURL = "https://fcm.googleapis.com/";
    public static final String googleAPIUrl = "https://maps.googleapis.com/";

    private static double base_fare = 2.55;
    private static double time_rate = 0.35;
    private static double distance_rate = 1.75;

    public static double getPrice(double km,int min)
    {
        return (base_fare+(time_rate*min)+(distance_rate*km));

    }

    public static IFCMService getFCMService()
    {
        return FCMClient.getClient(fcmURL).create(IFCMService.class);
    }
    public static IGoogleAPI getGoogleService()
    {
        return GoogleMapAPI.getClient(googleAPIUrl).create(IGoogleAPI.class);
    }

}

package com.example.jagjot.androidriderapp.Model;

/**
 * Created by SaRb Chauhan on 3/5/2018.
 */

public class Token {
    private String token;

    public Token() {
    }

    public Token(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}

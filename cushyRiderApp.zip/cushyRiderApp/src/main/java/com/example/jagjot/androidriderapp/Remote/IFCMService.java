package com.example.jagjot.androidriderapp.Remote;

import com.example.jagjot.androidriderapp.Model.FCMResponse;
import com.example.jagjot.androidriderapp.Model.Sender;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

/**
 * Created by SaRb Chauhan on 3/4/2018.
 */

public interface IFCMService {
    @Headers({
            "Content-Type:application/json",
            "Authorization:key=AAAAbfRVpVc:APA91bEsX-VYupTmQdoYaT1ZjkYUjkkbB_eCCtM57HOb7rveGANDukHSwRSbxeXZUb5kuWiPfX4kx_WM5S59GcazYsUPMkDXMoDVdvd58u7uDfkhVeDBXV4HgSfVukhQfRcXvQAPlOjj"
    })
    @POST("fcm/send")
    Call<FCMResponse> sendMessage(@Body Sender body);
}

package com.example.jagjot.androidriderapp.Model;

/**
 * Created by SaRb Chauhan on 3/8/2018.
 */

public class Notification {
    public String title;
    public  String body;

    public Notification(String title, String body) {
        this.title = title;
        this.body = body;
    }


}
